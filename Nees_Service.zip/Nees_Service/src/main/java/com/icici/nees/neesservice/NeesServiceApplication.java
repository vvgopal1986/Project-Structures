package com.icici.nees.neesservice;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class NeesServiceApplication {

	public static void main(String[] args) {
		SpringApplication.run(NeesServiceApplication.class, args);
	}

}
