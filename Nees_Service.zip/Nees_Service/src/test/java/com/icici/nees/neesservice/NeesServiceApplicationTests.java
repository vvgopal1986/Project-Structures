package com.icici.nees.neesservice;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class NeesServiceApplicationTests {

	@Test
	void contextLoads() {
	}

}
