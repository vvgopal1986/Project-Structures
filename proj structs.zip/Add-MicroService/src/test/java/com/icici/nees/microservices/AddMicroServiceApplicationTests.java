package com.icici.nees.microservices;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class AddMicroServiceApplicationTests {

	@Test
	void contextLoads() {
	}

}
